function contact()
{
  var styling = {
    textAlign:"center",
    backgroundColor:"blue",
    color:"white"
  }
  return (
    <div>
      <h1 style={styling}>Contact page</h1>
    </div>
  )
}
export default contact