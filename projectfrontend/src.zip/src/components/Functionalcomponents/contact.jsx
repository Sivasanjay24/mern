function contact()
{
  
  return (
    <div>
      <h1>Contact page</h1>
    </div>
  )
}
export default contact