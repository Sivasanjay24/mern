function details()
{
  
  return (
    <div>
      <h1>Signup page</h1>
    </div>
  )
}
export default details