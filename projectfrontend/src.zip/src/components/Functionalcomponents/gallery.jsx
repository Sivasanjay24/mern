function gallery()
{
  var styling = {
    textAlign:"center",
    backgroundColor:"blue",
    color:"white"
  }
  
  return (
    <div>
      <h1 style={styling}>Gallery page</h1>
    </div>
  )
}
export default gallery