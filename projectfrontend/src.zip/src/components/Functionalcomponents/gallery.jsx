function gallery()
{
  
  return (
    <div>
      <h1>Gallery page</h1>
    </div>
  )
}
export default gallery