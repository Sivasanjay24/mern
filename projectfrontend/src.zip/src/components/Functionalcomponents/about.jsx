import { useState } from 'react'

function about()
{
  return (
    <div>
      <h1>About Page</h1>
    </div>
  );
}
export default about