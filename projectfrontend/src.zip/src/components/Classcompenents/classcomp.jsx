import React from "react";

class ClassCompeg extends React.Component{
  render()
  {
    return(
      <h1>Class Component Example</h1>
    )
  }
}
export default ClassCompeg